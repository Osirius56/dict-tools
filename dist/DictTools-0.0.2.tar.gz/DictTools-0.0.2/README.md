# DICT-TOOLS
Package python contenant des outils pour travailler avec les dictionnaires et json.
> * Tri par valeur de clé complexe
> * identification des clés différentes
